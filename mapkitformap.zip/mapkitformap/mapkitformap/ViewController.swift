import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate, UISearchBarDelegate {

    let mapView = MKMapView()
    let locationManager = CLLocationManager()
    
    let fromSearchBar = UISearchBar()
    let toSearchBar = UISearchBar()
    
    let zoomInButton = UIButton(type: .system)
    let zoomOutButton = UIButton(type: .system)
    let mapTypeButton = UIButton(type: .system)
    let currentLocationButton = UIButton(type: .system)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupMapView()
        setupSearchBars()
        setupButtons()
        setupLocation()
    }
    
    func setupMapView() {
        mapView.delegate = self
        mapView.showsUserLocation = true
        mapView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(mapView)
        
        NSLayoutConstraint.activate([
            mapView.topAnchor.constraint(equalTo: view.topAnchor),
            mapView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            mapView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            mapView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }
    
    func setupSearchBars() {
        fromSearchBar.placeholder = "From"
        toSearchBar.placeholder = "To"
        fromSearchBar.delegate = self
        toSearchBar.delegate = self
        
        fromSearchBar.translatesAutoresizingMaskIntoConstraints = false
        toSearchBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(fromSearchBar)
        view.addSubview(toSearchBar)
        
        NSLayoutConstraint.activate([
            fromSearchBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            fromSearchBar.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            fromSearchBar.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
            
            toSearchBar.topAnchor.constraint(equalTo: fromSearchBar.bottomAnchor, constant: 10),
            toSearchBar.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            toSearchBar.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10)
        ])
    }
    
    func setupButtons() {
        // Zoom In
        zoomInButton.setTitle("+", for: .normal)
        zoomInButton.backgroundColor = .systemGray
        zoomInButton.tintColor = .white
        zoomInButton.layer.cornerRadius = 25
        zoomInButton.addTarget(self, action: #selector(zoomInTapped), for: .touchUpInside)
        zoomInButton.translatesAutoresizingMaskIntoConstraints = false
        
        // Zoom Out
        zoomOutButton.setTitle("-", for: .normal)
        zoomOutButton.backgroundColor = .systemGray
        zoomOutButton.tintColor = .white
        zoomOutButton.layer.cornerRadius = 25
        zoomOutButton.addTarget(self, action: #selector(zoomOutTapped), for: .touchUpInside)
        zoomOutButton.translatesAutoresizingMaskIntoConstraints = false
        
        // Map Type
        mapTypeButton.setTitle("Map Type", for: .normal)
        mapTypeButton.backgroundColor = .systemBlue
        mapTypeButton.tintColor = .white
        mapTypeButton.layer.cornerRadius = 8
        mapTypeButton.addTarget(self, action: #selector(mapTypeTapped), for: .touchUpInside)
        mapTypeButton.translatesAutoresizingMaskIntoConstraints = false
        
        // Current Location
        currentLocationButton.setTitle("Current Location", for: .normal)
        currentLocationButton.backgroundColor = .systemGreen
        currentLocationButton.tintColor = .white
        currentLocationButton.layer.cornerRadius = 8
        currentLocationButton.addTarget(self, action: #selector(currentLocationTapped), for: .touchUpInside)
        currentLocationButton.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(zoomInButton)
        view.addSubview(zoomOutButton)
        view.addSubview(mapTypeButton)
        view.addSubview(currentLocationButton)
        
        NSLayoutConstraint.activate([
            zoomInButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            zoomInButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -100),
            zoomInButton.widthAnchor.constraint(equalToConstant: 50),
            zoomInButton.heightAnchor.constraint(equalToConstant: 50),
            
            zoomOutButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            zoomOutButton.bottomAnchor.constraint(equalTo: zoomInButton.topAnchor, constant: -10),
            zoomOutButton.widthAnchor.constraint(equalToConstant: 50),
            zoomOutButton.heightAnchor.constraint(equalToConstant: 50),
            
            mapTypeButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            mapTypeButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -60),
            mapTypeButton.widthAnchor.constraint(equalToConstant: 120),
            mapTypeButton.heightAnchor.constraint(equalToConstant: 40),
            
            currentLocationButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            currentLocationButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -10),
            currentLocationButton.widthAnchor.constraint(equalToConstant: 160),
            currentLocationButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    func setupLocation() {
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    // MARK: - Button Actions
    @objc func zoomInTapped() {
        var region = mapView.region
        region.span.latitudeDelta /= 2
        region.span.longitudeDelta /= 2
        mapView.setRegion(region, animated: true)
    }
    
    @objc func zoomOutTapped() {
        var region = mapView.region
        region.span.latitudeDelta *= 2
        region.span.longitudeDelta *= 2
        mapView.setRegion(region, animated: true)
    }
    
    @objc func mapTypeTapped() {
        switch mapView.mapType {
        case .standard:
            mapView.mapType = .satellite
        case .satellite:
            mapView.mapType = .hybrid
        default:
            mapView.mapType = .standard
        }
    }
    
    @objc func currentLocationTapped() {
        if let currentLocation = locationManager.location?.coordinate {
            let region = MKCoordinateRegion(center: currentLocation, latitudinalMeters: 1000, longitudinalMeters: 1000)
            mapView.setRegion(region, animated: true)
            
            mapView.removeAnnotations(mapView.annotations)
            let annotation = MKPointAnnotation()
            annotation.coordinate = currentLocation
            annotation.title = "You are here"
            mapView.addAnnotation(annotation)
        } else {
            print("Current location not available")
        }
    }
    
    // MARK: - SearchBar Delegate
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        guard let text = searchBar.text, !text.isEmpty else { return }
        
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(text) { [weak self] (placemarks, error) in
            guard let self = self else { return }
            if let placemark = placemarks?.first, let location = placemark.location {
                let annotation = MKPointAnnotation()
                annotation.coordinate = location.coordinate
                annotation.title = text
                self.mapView.addAnnotation(annotation)
                
                let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
                self.mapView.setRegion(region, animated: true)
                
                // If both from & to filled, draw route
                self.drawRouteIfNeeded()
            }
        }
    }
    
    func drawRouteIfNeeded() {
        guard let fromText = fromSearchBar.text, !fromText.isEmpty,
              let toText = toSearchBar.text, !toText.isEmpty else { return }
        
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(fromText) { [weak self] (fromPlacemarks, _) in
            guard let self = self, let fromLocation = fromPlacemarks?.first?.location else { return }
            
            geocoder.geocodeAddressString(toText) { (toPlacemarks, _) in
                guard let toLocation = toPlacemarks?.first?.location else { return }
                
                let request = MKDirections.Request()
                request.source = MKMapItem(placemark: MKPlacemark(coordinate: fromLocation.coordinate))
                request.destination = MKMapItem(placemark: MKPlacemark(coordinate: toLocation.coordinate))
                request.transportType = .automobile
                
                let directions = MKDirections(request: request)
                directions.calculate { response, error in
                    if let route = response?.routes.first {
                        self.mapView.removeOverlays(self.mapView.overlays)
                        self.mapView.addOverlay(route.polyline)
                        print("Distance: \(route.distance) meters")
                        print("Estimated Time: \(route.expectedTravelTime) seconds")
                        
                        let region = MKCoordinateRegion(route.polyline.boundingMapRect)
                        self.mapView.setRegion(region, animated: true)
                    }
                }
            }
        }
    }
    
    // MARK: - MapView Delegate
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let polyline = overlay as? MKPolyline {
            let renderer = MKPolylineRenderer(polyline: polyline)
            renderer.strokeColor = .systemRed
            renderer.lineWidth = 5
            return renderer
        }
        return MKOverlayRenderer(overlay: overlay)
    }
}
